package pauloquirosgomez.avance2.avance2clienteservidor;

import java.util.ArrayList;
import java.io.*;

// Clase que gestiona listas de clientes y productos, y permite guardarlos/cargarlos
public class GestorDatos {
    public ArrayList<Cliente> clientes = new ArrayList<>();
    public ArrayList<Producto> productos = new ArrayList<>();

    // Agrega un cliente a la lista
    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    // Agrega un producto a la lista
    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    // Guarda los datos en archivos .ser (serialización)
    public void guardarDatos() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("clientes.ser"))) {
            out.writeObject(clientes);
        } catch (Exception e) {
            System.out.println("Error al guardar clientes: " + e.getMessage());
        }

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("productos.ser"))) {
            out.writeObject(productos);
        } catch (Exception e) {
            System.out.println("Error al guardar productos: " + e.getMessage());
        }
    }

    // Carga los datos desde los archivos
    public void cargarDatos() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("clientes.ser"))) {
            clientes = (ArrayList<Cliente>) in.readObject();
        } catch (Exception e) {
            System.out.println("No se pudo cargar clientes.");
        }

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("productos.ser"))) {
            productos = (ArrayList<Producto>) in.readObject();
        } catch (Exception e) {
            System.out.println("No se pudo cargar productos.");
        }
    }
}

