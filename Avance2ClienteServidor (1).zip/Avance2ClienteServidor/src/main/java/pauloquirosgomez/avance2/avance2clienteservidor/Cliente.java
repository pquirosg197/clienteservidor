package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.Serializable;

// Clase base que representa a un cliente normal
public class Cliente implements Serializable {
    protected String nombre;
    protected String cedula;

    // Constructor que recibe nombre y cédula
    public Cliente(String nombre, String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }

    // Método que devuelve la información del cliente (puede ser sobrescrito)
    public String getInfo() {
        return "Cliente Regular - Nombre: " + nombre + ", Cédula: " + cedula;
    }
}
