package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.PrintWriter;

// Clase que genera una factura en un archivo de texto
public class Factura {

    // Método estático para generar el archivo de factura
    public static void generar(String cedulaCliente, String nombreProducto, int cantidad, double precioUnitario) {
        double total = cantidad * precioUnitario;

        try {
            // El archivo incluirá la cédula del cliente
            String nombreArchivo = "factura_" + cedulaCliente + ".txt";
            PrintWriter writer = new PrintWriter(nombreArchivo);

            writer.println("Factura para cliente con cédula: " + cedulaCliente);
            writer.println("Producto: " + nombreProducto);
            writer.println("Cantidad: " + cantidad);
            writer.println("Precio unitario: " + precioUnitario);
            writer.println("Total a pagar: " + total);

            writer.close(); // Cerramos el archivo
            System.out.println("Factura generada correctamente.");
        } catch (Exception e) {
            System.out.println("Error al generar factura: " + e.getMessage());
        }
    }
}
