package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.Serializable;

// Clase que representa un producto
public class Producto implements Serializable {
    private String nombre;
    private double precio;

    // Constructor que inicializa el nombre y precio del producto
    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    // Método que devuelve la información del producto
    public String getInfo() {
        return "Producto: " + nombre + ", Precio: " + precio;
    }

    // Getters necesarios
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }
}
