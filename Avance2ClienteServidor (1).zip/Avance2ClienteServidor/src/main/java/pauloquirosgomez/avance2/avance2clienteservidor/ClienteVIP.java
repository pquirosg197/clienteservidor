package pauloquirosgomez.avance2.avance2clienteservidor;

// Clase ClienteVIP hereda de Cliente
public class ClienteVIP extends Cliente {

    private double descuento;

    // Constructor que además recibe un porcentaje de descuento
    public ClienteVIP(String nombre, String cedula, double descuento) {
        super(nombre, cedula); // Llamamos al constructor de la clase padre
        this.descuento = descuento;
    }

    // Método sobrescrito (polimorfismo): muestra la info incluyendo el descuento
    public String getInfo() {
        return "Cliente VIP - Nombre: " + nombre + ", Cédula: " + cedula + ", Descuento: " + descuento + "%";
    }
}

