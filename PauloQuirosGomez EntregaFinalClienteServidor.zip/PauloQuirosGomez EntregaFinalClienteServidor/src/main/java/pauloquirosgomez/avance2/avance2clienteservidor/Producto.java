package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.Serializable;

// Clase base para todos los productos. 
// Implementa Serializable para ser enviada por la red.
public class Producto implements Serializable {
    protected String nombre;
    protected double precio;
    protected int stock;

    // Constructor para crear un nuevo producto.
    public Producto(String nombre, double precio, int stock) {
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }
    
    // Método para obtener el nombre del producto.
    public String getNombre() {
        return nombre;
    }
    
    // Método para obtener el precio del producto.
    public double getPrecio() {
        return precio;
    }
    
    // Método para obtener el stock (cantidad disponible) del producto.
    public int getStock() {
        return stock;
    }
    
    // Método para actualizar el stock. 
    // Esto es útil después de una venta.
    public void setStock(int stock) {
        this.stock = stock;
    }
    
    // Método para mostrar la información del producto.
    public String getInfo() {
        return "Producto: " + nombre + ", Precio: " + precio + ", Stock: " + stock;
    }
}