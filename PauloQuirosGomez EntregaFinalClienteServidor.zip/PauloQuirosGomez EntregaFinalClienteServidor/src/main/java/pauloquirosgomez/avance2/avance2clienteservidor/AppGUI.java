package pauloquirosgomez.avance2.avance2clienteservidor;

import javax.swing.JOptionPane;
import java.io.*;
import java.net.*;

public class AppGUI {

    public static void main(String[] args) {
        // Se establece la conexión con el servidor. "localhost" porque el servidor está en la misma máquina.
        try (Socket socket = new Socket("localhost", 12345);
             ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream())) {

            while (true) {
                // Se muestra un menú para que el usuario elija una acción.
                String opcion = JOptionPane.showInputDialog(
                    "--- Menú Fidecompro ---\n" +
                    "1. Registrar cliente regular\n" +
                    "5. Salir"
                );

                if (opcion == null) break;

                switch (opcion) {
                    case "1" -> {
                        String nombre = JOptionPane.showInputDialog("Nombre del cliente:");
                        String cedula = JOptionPane.showInputDialog("Cédula del cliente:");
                        
                        // Se crea el objeto Cliente y se envía al servidor para que lo procese.
                        salida.writeObject("registrar_cliente");
                        salida.writeObject(new Cliente(nombre, cedula));
                        
                        // Se espera la respuesta del servidor para mostrarle un mensaje al usuario.
                        String respuesta = (String) entrada.readObject();
                        JOptionPane.showMessageDialog(null, respuesta);
                    }
                    case "5" -> {
                        salida.writeObject("guardar_y_salir");
                        JOptionPane.showMessageDialog(null, "Gracias por usar Fidecompro.");
                        return;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexión con el servidor: " + e.getMessage());
        }
    }
}