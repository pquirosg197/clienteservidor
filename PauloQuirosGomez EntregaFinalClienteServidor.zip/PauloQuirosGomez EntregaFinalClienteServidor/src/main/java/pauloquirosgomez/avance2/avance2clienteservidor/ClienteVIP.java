package pauloquirosgomez.avance2.avance2clienteservidor;

// ClienteVIP hereda de Cliente, lo que significa que es un tipo de Cliente.
public class ClienteVIP extends Cliente {
    
    private double descuento;

    // Constructor de ClienteVIP.
    // Llama al constructor de la clase padre (Cliente) y añade el descuento.
    public ClienteVIP(String nombre, String cedula, double descuento) {
        super(nombre, cedula);
        this.descuento = descuento;
    }
    
    // Se sobrescribe el método getInfo() para incluir el descuento.
    @Override
    public String getInfo() {
        return "Cliente VIP - Nombre: " + nombre + ", Cédula: " + cedula + ", Descuento: " + descuento + "%";
    }

    // Se sobrescribe el método para calcular el descuento.
    // Aplica el porcentaje de descuento al total.
    @Override
    public double calcularDescuento(double total) {
        return total * (descuento / 100);
    }
}