package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

// La clase Factura representa una venta.
// Contiene el cliente, la lista de productos y la fecha.
public class Factura implements Serializable {
    
    private Cliente cliente;
    private ArrayList<Producto> productos = new ArrayList<>();
    private Date fecha;
    
    // Constructor de la factura.
    // Se crea con un cliente y una lista de productos.
    public Factura(Cliente cliente, ArrayList<Producto> productos) {
        this.cliente = cliente;
        this.productos = productos;
        this.fecha = new Date(); // La fecha actual.
    }

    // Método para calcular el total de la factura.
    public double calcularTotal() {
        double subtotal = 0;
        for (Producto producto : productos) {
            subtotal += producto.getPrecio();
        }
        // Aplica el descuento del cliente VIP (polimorfismo).
        return subtotal - cliente.calcularDescuento(subtotal);
    }
    
    // Método para obtener la información completa de la factura.
    public String getInfo() {
        StringBuilder info = new StringBuilder();
        info.append("--- Factura ---\n");
        info.append("Fecha: ").append(fecha).append("\n");
        info.append("Cliente: ").append(cliente.getInfo()).append("\n");
        info.append("Productos:\n");
        for (Producto producto : productos) {
            info.append("- ").append(producto.getInfo()).append("\n");
        }
        info.append("Total a pagar: ").append(calcularTotal()).append("\n");
        return info.toString();
    }
}