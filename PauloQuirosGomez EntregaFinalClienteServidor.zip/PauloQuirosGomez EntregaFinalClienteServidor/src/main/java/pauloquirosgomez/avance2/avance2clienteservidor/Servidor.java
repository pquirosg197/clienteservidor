import java.io.*;
import java.net.*;
import java.sql.SQLException;

public class Servidor {
    public static void main(String[] args) {
        // GestorDatos se conecta a la base de datos (Derby en tu caso).
        GestorDatos gestor = new GestorDatos(); 
        
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Servidor iniciado. Esperando clientes...");
            
            Socket clienteSocket = serverSocket.accept();
            System.out.println("Cliente conectado desde " + clienteSocket.getInetAddress());
            
            ObjectInputStream entrada = new ObjectInputStream(clienteSocket.getInputStream());
            ObjectOutputStream salida = new ObjectOutputStream(clienteSocket.getOutputStream());

            while (true) {
                // Leer el comando del cliente.
                String comando = (String) entrada.readObject();

                switch (comando) {
                    case "registrar_cliente" -> {
                        Cliente cliente = (Cliente) entrada.readObject();
                        gestor.registrarCliente(cliente);
                        salida.writeObject("Cliente registrado con éxito.");
                    }
                    // ... otros comandos ...
                    case "guardar_y_salir" -> {
                        // Con la base de datos, los cambios se guardan al instante.
                        // No es necesario un método "guardar".
                        System.out.println("Cerrando la conexión del cliente.");
                        return; // O break del bucle para cerrar el servidor
                    }
                }
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}