package pauloquirosgomez.avance2.avance2clienteservidor;

import java.sql.*;
import java.util.ArrayList;

// Esta clase maneja toda la interacción con la base de datos de Derby.
// Funciona como la capa de acceso a datos del servidor.
public class GestorDatos {
    
    private Connection conexion;
    
    public GestorDatos() {
        try {
            // Carga el driver JDBC de Derby.
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            
            // Establece la conexión con la base de datos.
            // La opción 'create=true' ya no es necesaria si la base de datos ya existe.
            this.conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/fidecompro");
            System.out.println("Conexión a la base de datos de Derby exitosa.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Registra un cliente en la base de datos.
     * Utiliza un PreparedStatement para prevenir inyecciones SQL.
     * @param cliente El objeto Cliente (puede ser Cliente o ClienteVIP).
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public void registrarCliente(Cliente cliente) throws SQLException {
        // La sentencia SQL para insertar datos, incluyendo el tipo de cliente.
        String sql = "INSERT INTO CLIENTES (NOMBRE, CEDULA, TIPO) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNombre());
            stmt.setString(2, cliente.getCedula());
            // Guarda si el cliente es regular o VIP.
            stmt.setString(3, cliente instanceof ClienteVIP ? "VIP" : "Regular");
            stmt.executeUpdate(); // Ejecuta la inserción.
        }
    }

    /**
     * Busca un cliente en la base de datos por su cédula.
     * @param cedula La cédula del cliente a buscar.
     * @return El objeto Cliente si se encuentra, de lo contrario, null.
     * @throws SQLException Si ocurre un error de base de datos.
     */
    public Cliente buscarCliente(String cedula) throws SQLException {
        String sql = "SELECT nombre, cedula, tipo FROM CLIENTES WHERE cedula = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, cedula);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String nombre = rs.getString("nombre");
                    String tipo = rs.getString("tipo");
                    
                    if ("VIP".equals(tipo)) {
                         // Lógica para obtener el descuento del cliente VIP desde la BD
                         // (por simplicidad, se puede asumir un valor fijo por ahora)
                         return new ClienteVIP(nombre, cedula, 10.0); // Ejemplo de descuento 10%
                    }
                    return new Cliente(nombre, cedula);
                }
            }
        }
        return null; // Retorna null si no encuentra el cliente.
    }
    
    /**
     * Registra un producto en la base de datos.
     * @param producto El objeto Producto a registrar.
     * @throws SQLException Si ocurre un error de base de datos.
     */
    public void registrarProducto(Producto producto) throws SQLException {
        String sql = "INSERT INTO PRODUCTOS (NOMBRE, PRECIO, STOCK) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
            stmt.setString(1, producto.getNombre());
            stmt.setDouble(2, producto.getPrecio());
            stmt.setInt(3, producto.getStock());
            stmt.executeUpdate();
        }
    }
    
    /**
     * Obtiene todos los productos de la base de datos.
     * @return Una lista de objetos Producto.
     * @throws SQLException Si ocurre un error de base de datos.
     */
    public ArrayList<Producto> obtenerProductos() throws SQLException {
        ArrayList<Producto> productos = new ArrayList<>();
        String sql = "SELECT nombre, precio, stock FROM PRODUCTOS";
        try (Statement stmt = conexion.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                productos.add(new Producto(rs.getString("nombre"), rs.getDouble("precio"), rs.getInt("stock")));
            }
        }
        return productos;
    }
    
    // Método para generar una factura, actualizando el inventario y registrando la venta.
    public void generarFactura(Cliente cliente, Producto producto, int cantidad) throws SQLException {
        try {
            // Se inicia una transacción para asegurar que todas las operaciones se completen o ninguna.
            conexion.setAutoCommit(false);
            
            // 1. Verificar si hay suficiente stock.
            if (producto.getStock() < cantidad) {
                throw new SQLException("Stock insuficiente para el producto: " + producto.getNombre());
            }
            
            // 2. Actualizar el stock del producto en la base de datos.
            String updateSql = "UPDATE PRODUCTOS SET stock = stock - ? WHERE nombre = ?";
            try (PreparedStatement updateStmt = conexion.prepareStatement(updateSql)) {
                updateStmt.setInt(1, cantidad);
                updateStmt.setString(2, producto.getNombre());
                updateStmt.executeUpdate();
            }
            
            // 3. Registrar la factura en la tabla FACTURAS.
            String facturaSql = "INSERT INTO FACTURAS (fecha, cliente_cedula) VALUES (CURRENT_TIMESTAMP, ?)";
            try (PreparedStatement facturaStmt = conexion.prepareStatement(facturaSql, Statement.RETURN_GENERATED_KEYS)) {
                facturaStmt.setString(1, cliente.getCedula());
                facturaStmt.executeUpdate();
                
                // Obtener el ID de la factura recién creada.
                ResultSet rs = facturaStmt.getGeneratedKeys();
                int facturaId = -1;
                if (rs.next()) {
                    facturaId = rs.getInt(1);
                }
                
                // 4. Registrar el producto vendido en la tabla ITEMS_FACTURA.
                String itemsSql = "INSERT INTO ITEMS_FACTURA (factura_id, producto_id, cantidad) VALUES (?, ?, ?)";
                try (PreparedStatement itemsStmt = conexion.prepareStatement(itemsSql)) {
                    itemsStmt.setInt(1, facturaId);
                    // Deberías buscar el ID del producto por su nombre
                    // (simplificamos asumiendo que el ID es un atributo de Producto)
                    itemsStmt.setInt(2, 0); // Reemplazar con el ID real del producto
                    itemsStmt.setInt(3, cantidad);
                    itemsStmt.executeUpdate();
                }
            }
            
            // Si todas las operaciones fueron exitosas, se confirman los cambios.
            conexion.commit();
            System.out.println("Factura generada y stock actualizado correctamente.");
        } catch (SQLException e) {
            // Si algo falla, se revierte toda la transacción.
            conexion.rollback();
            throw e;
        } finally {
            // Restablecer el auto-commit.
            conexion.setAutoCommit(true);
        }
    }
}