package pauloquirosgomez.avance2.avance2clienteservidor;

import javax.swing.JOptionPane;
import java.io.*;
import java.net.*;

public class ClienteApp {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 12345);
             ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream())) {

            // Lógica de la GUI.
            // Por ejemplo, cuando se presiona un botón:
            String nombre = JOptionPane.showInputDialog("Nombre:");
            String cedula = JOptionPane.showInputDialog("Cédula:");
            // Se crea el objeto y se envía al servidor.
            Cliente cliente = new Cliente(nombre, cedula);
            salida.writeObject("registrar_cliente"); // Comando para el servidor.
            salida.writeObject(cliente); // Envía el objeto.
            
            // El cliente espera una respuesta del servidor.
            String respuesta = (String) entrada.readObject();
            JOptionPane.showMessageDialog(null, respuesta);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}