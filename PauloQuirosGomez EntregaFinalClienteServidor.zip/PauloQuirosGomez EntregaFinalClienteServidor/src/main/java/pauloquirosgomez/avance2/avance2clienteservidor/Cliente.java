package pauloquirosgomez.avance2.avance2clienteservidor;

import java.io.Serializable;

// La clase Cliente es la base para todos los tipos de clientes.
// Implementa Serializable para poder ser enviada por la red.
public class Cliente implements Serializable {
    protected String nombre;
    protected String cedula;
    
    // Constructor de la clase Cliente. 
    // Se usa para crear nuevos objetos Cliente.
    public Cliente(String nombre, String cedula) {
        this.nombre = nombre;
        this.cedula = cedula;
    }

    // Método para obtener el nombre del cliente.
    public String getNombre() {
        return nombre;
    }
    
    // Método para obtener la cédula del cliente.
    public String getCedula() {
        return cedula;
    }
    
    // Método getInfo() para mostrar la información del cliente.
    // Este método se sobrescribirá en las clases hijas (polimorfismo).
    public String getInfo() {
        return "Cliente Regular - Nombre: " + nombre + ", Cédula: " + cedula;
    }
    
    // Método para calcular el descuento.
    // Por defecto, un cliente regular no tiene descuento.
    public double calcularDescuento(double total) {
        return 0;
    }
}